<form action="/" method="get">
		<input type="search" name="s" id="search" value="<?php the_search_query(); ?>" placeholder="BUSCAR" />
</form>